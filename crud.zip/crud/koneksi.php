<?php
$host = "localhost"; //Nama Database
$username = "root"; // Username
$password = ""; //password
$database = "crudrb"; // Nama Databasenya

// Koneksi Ke Mysql Dengan PDO
$pdo = new PDO('mysql:host='.$host.';dbname='.$database, $username, $password);
?>